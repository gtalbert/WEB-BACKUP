<!DOCTYPE html>
<html lang="en">
<head>
	<title>Astro Living</title>
	<meta charset="utf-8">
	<meta name="author" content="albert castro">
    <meta name="description" content="real estate dammam, saudi arabia"/>
    <meta name="keywords" content="apartments,investments,mall,shopping, mall saudi arabia, mall-dammam province, Residential Mall Dammam,">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0" />
	
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" type="text/css" href="css/responsive.css">

	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/main.js"></script>
</head>
<body>

	<section class="hero">
		<header>
			<div class="wrapper">
				<a href="#"><img src="img/logo.png" class="logo" alt="" titl=""/></a>
				<a href="#" class="hamburger"></a>
				<nav>
					<ul>
						<li><a href="#">inquiries</a></li>
						<li><a href="#">news and events</a></li>
                        <li><a href="#">info</a></li>
						<li><a href="#">residents</a></li>
						<li><a href="#">catalogs</a></li>
						<li><a href="#">about</a></li>
					</ul>
					<a href="#" class="login_btn">Login</a>
				</nav>
			</div>
		</header><!--  end header section  -->

			<section class="caption">
				<h2 class="caption">Astro Complex Residence</h2>
				<h3 class="properties">Find your Dream Home</h3>
			</section>
	</section><!--  end hero section  -->


	<section class="search">
		<div class="wrapper">
			<form action="#" method="post">
				<input type="text" id="search" name="search" placeholder="What is your Budget Range?"  autocomplete="off"/>
				<input type="submit" id="submit_search" name="submit_search"/>
			</form>
			<a href="#" class="advanced_search_icon" id="advanced_search_btn"></a>
		</div>

		<div class="advanced_search">
			<div class="wrapper">
				<span class="arrow"></span>
				<form action="#" method="post">
					
					<div class="search_fields">
						<input type="text" class="float" id="min_price" name="min_price" placeholder="Budget Range"  autocomplete="off">

						<hr class="field_sep float"/>

						<input type="text" class="float" id="max_price" name="max_price" placeholder="Number of Bedrooms"  autocomplete="off">
					</div>
					
                    
					<input type="submit" id="submit_search" name="submit_search"/>
				</form>
			</div>
		</div><!--  end advanced search section  -->
	</section><!--  end search section  -->
  

	<section class="listings">
		<div class="wrapper">
			<ul class="properties_list">
				<li>
					<a href="img/shopping-saudi-dammam-safwa.pdf" target="new">
						<img src="img/property_1.jpg" alt="" title="" class="property_img"/>
					</a>
					<span class="price">as Low As SR2,679*</span>
					<div class="property_details">
						<h1>
							<a href="img/shopping-saudi-dammam-safwa.pdf" target="new">View Floor Layout</a>
                             <h2><span class="property_size_color">Inquire</span></h2>
						</h1>
						<h2> 2 Bedrooms 3 bathrooms... <span class="property_size">(186ftsq)</span></h2>
					</div>
				</li>
                <!---------------->
				<li>
					<a href="img/apartment-saudi-forsale.pdf" target="new">
						<img src="img/property_2.jpg" alt="" title="" class="property_img"/>
					</a>
					<span class="price">as Low As SR5,479*</span>
					<div class="property_details">
						<h1>
							<a href="img/apartment-saudi-forsale.pdf" target="new">View Floor Layout1</a>
                            <h2><span class="property_size_color">Inquire</span></h2>
						</h1>
						<h2> 4 Bedrooms 5 bathrooms... <span class="property_size">(317ftsq)</span></h2>
					</div>
				</li>
                 <!---------------->
				<li>
					<a href="img/astro-complex-dammam-safwa.pdf" target="new">
						<img src="img/property_3.jpg" alt="" title="" class="property_img"/>
					</a>
					<span class="price">as Low As SR3,600*</span>
					<div class="property_details">
						<h1>
							<a href="img/astro-complex-dammam-safwa.pdf" target="new">View Floor Layout</a>
                            <h2><span class="property_size_color">Inquire</span></h2>
						</h1>
						<h2> 4 Bedrooms, 5 bathrooms... <span class="property_size">(310ftsq)</span></h2>
					</div>
				</li>
                 <!---------------->
                 
				<li>
					<a href="img/dammam-safwa-shopping-mall.pdf" target="new">
						<img src="img/property_1.jpg" alt="" title="" class="property_img"/>
					</a>
					<span class="price">as Low As SR2,679*</span>
					<div class="property_details">
						<h1>
							<a href="img/dammam-safwa-shopping-mall.pdf" target="new">View Floor Layout</a>
                            <h2><span class="property_size_color">Inquire</span></h2>
						</h1>
						<h2> 2 Bedrooms, 2 Bathrooms... <span class="property_size">(157.8ftsq)</span></h2>
					</div>
				</li>
                  <!---------------->
				<li>
					<a href="img/dammam-shopping-mall-astro-complex.pdf" target="new">
						<img src="img/property_2.jpg" alt="" title="" class="property_img"/>
					</a>
					<span class="price">as Low As SR3,967*</span>
					<div class="property_details">
						<h1>
							<a href="img/dammam-shopping-mall-astro-complex.pdf" target="new">View Floor Layout</a>
                            <h2><span class="property_size_color">Inquire</span></h2>
						</h1>
						<h2> kitchen, 3 Bedrooms, 3 Bathrooms... <span class="property_size">(215ftsq)</span></h2>
					</div>
				</li>
                 <!---------------->
                
				<li>
					<a href="img/saudi-astro-complex-mall-apartment.pdf" target="new">
						<img src="img/property_3.jpg" alt="" title="" class="property_img"/>
					</a>
					<span class="price">as Low As SR3,967*</span>
					<div class="property_details">
						<h1>
							<a href="img/saudi-astro-complex-mall-apartment.pdf" target="new">View Floor Layout</a>
                            <h2><span class="property_size_color">Inquire</span></h2>
						</h1>
						<h2>kitchen, 3 Bedrooms, 3 Bathroom... <span class="property_size">(159ftsq)</span></h2>
					</div>
				</li>
                 <!---------------->
				<li>
					<a href="img/saudi-mall-shopping-area.pdf" target="new">
						<img src="img/property_1.jpg" alt="" title="" class="property_img"/>
					</a>
					<span class="price">as Low As SR2,679</span>
					<div class="property_details">
						<h1>
							<a href="img/saudi-mall-shopping-area.pdf" target="new">View Floor Layout</a>
                            <h2><span class="property_size_color">Inquire</span></h2>
						</h1>
						<h2> 2 Bedrooms, 2 Bathrooms... <span class="property_size">(288ftsq)</span></h2>
					</div>
				</li>
                 <!---------------->
				<li>
					<a href="img/saudi-mall-dammam-safwa.pdf" target="new">
						<img src="img/property_2.jpg" alt="" title="" class="property_img"/>
					</a>
					<span class="price">as Low as SR3,769</span>
					<div class="property_details">
						<h1>
							<a href="img/saudi-mall-dammam-safwa.pdf" target="new">View Floor Layout</a>
                            <h2><span class="property_size_color">Inquire</span></h2>
						</h1>
						<h2>3 Bedrooms, 3 Bathrooms... <span class="property_size">(314ftsq)</span></h2>
					</div>
				</li>
                 <!---------------->
				<li>
					<a href="img/dammam-safwa-shopping-center-mall.pdf" target="new">
						<img src="img/property_3.jpg" alt="" title="" class="View Floor Plan Layout"/>
					</a>
					<span class="price">as Low as SR3,679</span>
					<div class="property_details">
						<h1>
			<a href="img/dammam-safwa-shopping-center-mall.pdf" target="new">View Floor Layout</a> <h2><span class="property_size_color">Inquire</span></h2>                            
                            
						</h1>
						<h2> 3 Bedroom, 3 Bathroom... <span class="property_size">(316ftsq)</span></h2>
					</div>
				</li>
			</ul>
            
			<div class="more_listing">
				<a href="#" class="more_listing_btn">CONTACT US</a>
			</div>

<!------------------------------>



<div class="contactslists">
<table width="1090" border="1">
  <tr>
    <td>&nbsp; <h3 class="ico ico2">Beshry Mosaad Khaled</h3>
        <p>Marketing &amp; Sales Representative</p>
        <p>+966 564 004343</p>
        <p>elbeshry@spaceworldarabia.com</p>
        <p>For Pricing and Information</p>
        <p class="more"><a href="#" class="bul">Request a Catalog or Call</a></p></td>
    <td>&nbsp; <h3 class="ico ico2">Entessar Ali Alawami</h3>
        <p>Marketing &amp; Sales Representative</p>
        <p>&nbsp;+966 545 296078</p>
        <p>entessar@spaceworldarabia.com</p>
        <p>For Pricing and Information</p>
        <p class="more"><a href="#" class="bul">Request a Catalog or Call</a></p></td>
    <td>&nbsp;   <h3 class="ico ico2">Kumaravelan Arumugam</h3>
        <p>General Manager</p>
        <p>&nbsp;+966 540 732091</p>
        <p>kumar@spaceworldarabia.com</p>
        <p>For Pricing and Information</p>
        <p class="more"><a href="#" class="bul">Request a Catalog or Call</a></p></td>
    <td>&nbsp;<h3 class="ico ico2">Eqrar Haque</h3>
        <p>Operations Manager (Retail)</p>
        <p>&nbsp;+966 508 719087</p>
        <p>eqrar@spaceworldarabia.com</p>
        <p>For Pricing and Information</p>
        <p class="more"><a href="#" class="bul">Request a Catalog or Call</a></p></td>
  </tr>
</table>

  					            
		  </div>
  <!---------------------------------->          
            
		</div>
     
                
	</section>	<!--  end listing section  -->

	<footer>
		<div class="wrapper footer">
			<ul>
				
                                <li class="links">
					<ul>
						<li><a href="#">About</a></li>
						<li><a href="#">Support</a></li>
						<li><a href="#">Terms</a></li>
						<li><a href="#">Policy</a></li>
						<li><a href="#">Contact</a></li>
					</ul>
				</li>

				<li class="links">
					<ul>
						<li><a href="http://www.astrocomplex.me">Apartments</a></li>
						<li><a href="http://www.astrocomplex.me">Houses</a></li>
						<li><a href="http://www.astrocomplex.me">Villas</a></li>
						<li><a href="http://www.astrocomplex.me">Mansions</a></li>
						<li><a href="http://www.astrocomplex.me">Safwa</a></li>
					</ul>
				</li>

				<li class="links">
					<ul>
						<li><a href="http://www.astrocomplex.me">Real Estate</a></li>
						<li><a href="http://www.astrocomplex.me">Saudi Apartments</a></li>
						<li><a href="http://www.astrocomplex.me">Dammam Saudi</a></li>
						<li><a href="http://www.astrocomplex.me">Astro Mall</a></li>
						<li><a href="http://www.astrocomplex.me">Astro Living</a></li>
					</ul>
				</li>

				<li class="about">
					<p lang="ar"></p>
					<ul>
						<li><a href="https://www.facebook.com/%D9%85%D8%AC%D9%85%D8%B9-%D8%A3%D8%B3%D8%AA%D8%B1%D9%88-Astro-Complex-141776452656005/?fref=ts" class="facebook" target="_blank"></a></li>
						<li><a href="https://twitter.com/mall_astro" class="twitter" target="_blank"></a></li>
						<li><a href="http://plus.google.com/astroliving" class="google" target="_blank"></a></li>
						<li><a href="#" class="skype"></a></li>
					</ul>
				</li>
			</ul>
		</div>

		<div class="copyrights wrapper">
			Copyright © 2015 <a href="http://www.spaceworldarabia.com" target="_blank" class="ph_link" title="Astro Complex">AstroComplex.me</a>. All Rights Reserved.
		</div>
	</footer><!--  end footer  -->
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-56b8be1d7e50272d" async></script>
    <!--Start of Tawk.to Script-->
		<script type="text/javascript">
                var Tawk_API=Tawk_API||{}, Tawk_LoadStart=new Date();
                (function(){
                var s1=document.createElement("script"),s0=document.getElementsByTagName("script")[0];
                s1.async=true;
                s1.src='https://embed.tawk.to/56bc62814300ca1b560bad12/default';
                s1.charset='UTF-8';
                s1.setAttribute('crossorigin','*');
                s0.parentNode.insertBefore(s1,s0);
                })();
        </script>
    <!--End of Tawk.to Script-->
    
</body>
</html>